 #include <bits/stdc++.h>
using namespace std;
class Student
{
public:
    int roll;
    int cls;
    double gpa;
    Student(int roll, int cls, double gpa)
    {
        this->roll = roll;
        this->cls = cls;
        this->gpa = gpa;
    }
};
Student * fun()
{

  Student *sudipto= new Student (25, 9, 3.51);
    return sudipto;
}
int main()
{
    Student * raja= fun();
    cout<<raja->cls<<" "<<raja->roll<<" "<<raja->gpa<<endl;
    delete raja;
    cout<<raja->cls<<" "<<raja->roll<<" "<<raja->gpa<<endl;

    return 0;
}