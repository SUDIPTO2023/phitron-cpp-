 #include<bits/stdc++.h>
using namespace std;
int main()
{  
   string s;
   int x;
   cin>>x;
   getchar();
//    cin.getline(s,100);//char s[100] er khetrey i mean char er kkhetrey
    getline(cin,s);
    cout<<x<<endl;
    cout<<s<<endl;
    return 0;
}