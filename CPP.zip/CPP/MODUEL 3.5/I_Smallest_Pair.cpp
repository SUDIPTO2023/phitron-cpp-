#include <bits/stdc++.h>
using namespace std;
int main()
{
  int t;
  cin >> t;
  for (int i = 0; i < t; i++)
  {
    int n;
    cin >> n;
    long long int a[n];
     
    for (int i = 0; i < n; i++)
    {
      cin >> a[i];
    }
    long long mn=a[0]+a[1]+1;
    for (int i = 0; i < n; i++)
    {
      for (int j = i + 1; j < n; j++)
      {
        long long int val = a[i] + a[j] + j - i;
        mn = min(mn, val);
      }
    }

    cout << mn<<endl;
  }

  return 0;
}