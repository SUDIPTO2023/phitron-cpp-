 #include<bits/stdc++.h>
using namespace std;
class student
{   
    public:
    string name;
    int age;
    int mark;
    student(string name,int age,int mark)
    {
        this->name=name;
        this->age=age;
        this->mark=mark;
    }
    void print ()
    {
        cout<<name<<endl;
        cout<<age<<endl;
        cout<<mark<<endl;
    }
    int sum_mark_age()
    {

        return mark+age;

    }



};
int main()
{
    student sudipto("sudipto kumar chakrabarty Raja",21,99);
    sudipto.print();
   cout<< sudipto.sum_mark_age()<<endl;
    return 0;
}