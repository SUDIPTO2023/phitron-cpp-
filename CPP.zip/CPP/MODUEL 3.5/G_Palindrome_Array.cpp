 #include<bits/stdc++.h>
using namespace std;
int main()
{
  int n;
  cin>>n;
  int a[n];
  int temp=0;
  for (int i = 0; i < n; i++)
  {
    cin>>a[i];
  }
  int i=0;
  int j=n-1;
  
  while (i<=j)
  {
    if (a[i]==a[j])
    {
        i++;
        j--;
        temp++;
    }else
    {   temp=0;
        break;
    }
    
    
  }
 
  if (temp==0)
  {
    cout<<"NO";
  }else
  {
    cout<<"YES";
  }
  
  
  

    return 0;
}