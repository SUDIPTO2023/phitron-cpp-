#include <bits/stdc++.h>
using namespace std;
class Student
{
public:
    int cls;
    int roll;
    int gpa;
    Student(int cls, int roll, int gpa)
    {
        this->cls = cls;
        this->roll = roll;
        this->gpa = gpa;
    }
};

int main()
{
    // Student raja(9,13,5.01);
    Student *raja = new Student(9, 13, 5.01);

    cout << raja->cls << " " << raja->roll << " " << raja->gpa;
    return 0;
}