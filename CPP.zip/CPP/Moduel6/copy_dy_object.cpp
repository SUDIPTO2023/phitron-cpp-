 #include<bits/stdc++.h>
using namespace std;
class Cricketer
{
    public:
    string name;
    int age;
    Cricketer(string name,int age)
    {
        this->name=name;
        this->age=age;
    }
};
int main()
{
   Cricketer *sakib=  new Cricketer("sakib al hasan",35);
   Cricketer *soumya= new Cricketer("soumya sarkar",29);
cout<<sakib<<endl;
cout<<&sakib<<endl;

//    *soumya=*sakib;
//  delete sakib;
  
//    cout<<soumya->name<<" "<<soumya->age<<endl;
 
    return 0;
}