#include<bits/stdc++.h>
using namespace std;
int main()
{

 string a="raja";
 string b="raja";
 if (a==b)//cpp a direct compare korey
 {
    cout<<"sudipto";
 }else
 {
    cout<<"not same";
 }
 
 






}