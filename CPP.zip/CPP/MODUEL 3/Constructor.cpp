 #include<bits/stdc++.h>
using namespace std;
class Student{

    public:
    int id;
    int roll;
    double cgpa;
    Student(int id,int roll,double cgpa){
       this->id=id;
       this->roll=roll;
       this->cgpa=cgpa;

    }




};
int main()
{
   Student raja(50622,6954,3.51);
   cout<<raja.id<<endl;
   cout<<raja.roll<<endl;
   cout<<raja.cgpa<<endl;
   

    return 0;
}