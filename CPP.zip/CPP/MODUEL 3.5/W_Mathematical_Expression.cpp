#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a,   b,   ans;
    char c,c1;
    cin >> a >> c >> b >> c1 >> ans;
    int sum = a + b;
    int sub = a - b;
    int mul = a * b;
    if (c == '+')
    {

        if (sum == ans)
        {
            cout << "Yes";
        }
        else
        {
            cout << sum;
        }
    }
    else if (c == '-')
    {

        if (sub == ans)
        {
            cout << "Yes";
        }
        else
        {
            cout << sub;
        }
    }
    else if (c == '*')
    {

        if (mul == ans)
        {
            cout << "Yes";
        }
        else
        {
            cout << mul;
        }
    }

    return 0;
}