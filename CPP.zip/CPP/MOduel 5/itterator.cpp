#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin>>s;
    // cout<<*s.begin()<<endl;
    // cout<<*(s.end()-1)<<endl;

    //jodi prottec value k pointer er maddhomey access kortey cahi tailey iterator use kortety hobey

    //  string:: iterator it;//or we also use to auto
     for (auto it=s.begin();it<s.end();it++)
     {
        cout<<*it<<endl;
     }
     
    return 0;
}