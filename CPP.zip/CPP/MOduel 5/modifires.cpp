#include <bits/stdc++.h>
using namespace std;
int main()
{

    //     string a = "sudipto";
    //     string b = "raja";
    //     // a += b;//use
    //     // a.append(b);//ak e kaj korey oporer moto
    //     // cout << a;

    //    // a[7]="l";//its dosent work
    //    //a+="A"
    // //    a.push_back('A') ;//its work and use
    // //    a.pop_back();//autometic last element which i add before it will be delete
    // //    cout<<a;

    //      a="baba";
    //      a.assign("baba");//same oporer tar moto
    //      cout<<a;
    string s="sudipto_kumar_chakrabarty_Raja";
    // // s.erase(7,7);//just delete
    // s.replace(7,1,"SUDIPTO");//'_'<-ei jaigai full sudipto boashai dichey//replace and delete
    // cout<<s<<endl;
    s.insert(4,"ra");//ak e kaj replace dia o kora jai
    s.replace(4,0,"rapto");
    cout<<s;
    


    







    return 0;
}