 #include<bits/stdc++.h>
using namespace std;
class Student{
    public:
    int id;
    char name[100];
    char sec;
    int mark;
   

};
int main()
{
    int t;
    cin>>t;
    for (int i = 0; i < t; i++)
    {
        Student sakib,rakib,akib;
    cin>>sakib.id;
    cin>>sakib.name;
    cin>>sakib.sec;
    cin>>sakib.mark;
    cin>>rakib.id;
    cin>>rakib.name;
    cin>>rakib.sec;
    cin>>rakib.mark;
    cin>>akib.id;
    cin>>akib.name;
    cin>>akib.sec;
    cin>>akib.mark;
    if (sakib.mark>=rakib.mark&&sakib.mark>=akib.mark)
    {
        cout<<sakib.id<<" "<<sakib.name<<" "<<sakib.sec<<" "<<sakib.mark;
    }else if (rakib.mark>=sakib.mark&&rakib.mark>=akib.mark)
    {
        cout<<rakib.id<<" "<<rakib.name<<" "<<rakib.sec<<" "<<rakib.mark;
    }else
    {
        cout<<akib.id<<" "<<akib.name<<" "<<akib.sec<<" "<<akib.mark;
    }
    cout<<endl;
    }

    
    
    
    

    return 0;
}