#include <bits/stdc++.h>
using namespace std;
int main()
{
    char c[100001];
    while (cin.getline(c, 100001))
    {
        int va = strlen(c);
        sort(c,c+va);
        for (int i = 0; i < va; i++)
        {
            if (c[i] != ' ')
            {

                cout << c[i];
            }
        }
        cout<<endl;
    }

    return 0;
}